# Boostly Full-Stack

Aplikasi web full-stack sederhana menggunakan Express + SQLite.

## Jalankan di komputer
1. Install Node.js 18+.
2. Ekstrak ZIP.
3. Buka terminal di folder proyek.
4. Jalankan:
   npm install
   npm run dev
5. Buka http://localhost:3000

## Akun admin demo
Email: admin@boostly.local
Password: admin123

Database `boostly.db` otomatis dibuat saat server pertama kali dijalankan.

## Catatan produksi
Sebelum dipublikasikan, ganti SESSION_SECRET, gunakan HTTPS, gunakan password hashing yang lebih kuat (bcrypt/argon2), validasi input lebih ketat, rate limiting, CSRF protection, dan database PostgreSQL/MySQL. Sistem pembayaran/API provider belum terhubung.

Gunakan hanya layanan pemasaran yang transparan dan sesuai aturan platform.
