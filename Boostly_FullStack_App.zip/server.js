const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");

const app = express();
const db = new Database(path.join(__dirname, "boostly.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 balance INTEGER NOT NULL DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 platform TEXT NOT NULL,
 description TEXT,
 price_per_1000 INTEGER NOT NULL,
 active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 service_id INTEGER NOT NULL,
 target TEXT NOT NULL,
 quantity INTEGER NOT NULL,
 total INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(service_id) REFERENCES services(id)
);
CREATE TABLE IF NOT EXISTS transactions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 type TEXT NOT NULL,
 amount INTEGER NOT NULL,
 note TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const hash = p => crypto.createHash("sha256").update(p).digest("hex");
const adminEmail = "admin@boostly.local";
if (!db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail)) {
  db.prepare("INSERT INTO users(name,email,password_hash,role,balance) VALUES(?,?,?,?,?)")
    .run("Administrator", adminEmail, hash("admin123"), "admin", 0);
}
if (db.prepare("SELECT COUNT(*) c FROM services").get().c === 0) {
  const ins = db.prepare("INSERT INTO services(name,platform,description,price_per_1000) VALUES(?,?,?,?)");
  ins.run("Campaign Engagement","Instagram","Promosi engagement yang transparan untuk konten.",10000);
  ins.run("Campaign Reach","TikTok","Promosi jangkauan konten untuk audiens.",12000);
  ins.run("Video Promotion","YouTube","Promosi video/kanal dengan laporan order.",15000);
  ins.run("Social Campaign","Facebook","Campaign pemasaran sosial media.",10000);
}

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "boostly-change-this-secret",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:"lax",maxAge:86400000}
}));
app.use(express.static(path.join(__dirname,"public")));

function user(req,res,next){
  if(!req.session.userId) return res.status(401).json({error:"Silakan login."});
  req.user = db.prepare("SELECT id,name,email,role,balance FROM users WHERE id=?").get(req.session.userId);
  if(!req.user) return res.status(401).json({error:"Sesi tidak valid."});
  next();
}
function admin(req,res,next){
  user(req,res,()=> req.user.role==="admin" ? next() : res.status(403).json({error:"Akses admin diperlukan."}));
}

app.get("/api/services",(req,res)=>res.json(db.prepare("SELECT * FROM services WHERE active=1 ORDER BY id DESC").all()));
app.post("/api/register",(req,res)=>{
  const {name,email,password}=req.body;
  if(!name||!email||!password||password.length<6) return res.status(400).json({error:"Nama, email, dan password minimal 6 karakter wajib diisi."});
  try{
    const r=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name,email.toLowerCase(),hash(password));
    req.session.userId=r.lastInsertRowid;
    res.json({ok:true});
  }catch(e){res.status(400).json({error:"Email sudah terdaftar."});}
});
app.post("/api/login",(req,res)=>{
  const u=db.prepare("SELECT id,name,email,role FROM users WHERE email=? AND password_hash=?").get((req.body.email||"").toLowerCase(),hash(req.body.password||""));
  if(!u) return res.status(401).json({error:"Email atau password salah."});
  req.session.userId=u.id; res.json({ok:true,user:u});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",user,(req,res)=>res.json(req.user));

app.post("/api/orders",user,(req,res)=>{
  const {serviceId,target,quantity}=req.body;
  const service=db.prepare("SELECT * FROM services WHERE id=? AND active=1").get(serviceId);
  const qty=Number(quantity);
  if(!service||!target||!Number.isInteger(qty)||qty<1) return res.status(400).json({error:"Data order tidak valid."});
  const total=Math.ceil(qty/1000*service.price_per_1000);
  if(req.user.balance<total) return res.status(400).json({error:"Saldo tidak mencukupi. Hubungi admin untuk top up demo."});
  const tx=db.transaction(()=>{
    db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(total,req.user.id);
    const o=db.prepare("INSERT INTO orders(user_id,service_id,target,quantity,total) VALUES(?,?,?,?,?)").run(req.user.id,service.id,target,qty,total);
    db.prepare("INSERT INTO transactions(user_id,type,amount,note) VALUES(?,?,?,?)").run(req.user.id,"debit",-total,"Order #"+o.lastInsertRowid);
    return o.lastInsertRowid;
  });
  res.json({ok:true,orderId:tx(),total});
});
app.get("/api/orders",user,(req,res)=>{
  res.json(db.prepare(`SELECT o.*,s.name service_name,s.platform FROM orders o JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC`).all(req.user.id));
});
app.get("/api/transactions",user,(req,res)=>res.json(db.prepare("SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC").all(req.user.id)));

app.get("/api/admin/stats",admin,(req,res)=>{
  res.json({
    users:db.prepare("SELECT COUNT(*) c FROM users WHERE role='user'").get().c,
    orders:db.prepare("SELECT COUNT(*) c FROM orders").get().c,
    revenue:db.prepare("SELECT COALESCE(SUM(total),0) s FROM orders").get().s,
    pending:db.prepare("SELECT COUNT(*) c FROM orders WHERE status!='Completed'").get().c
  });
});
app.get("/api/admin/users",admin,(req,res)=>res.json(db.prepare("SELECT id,name,email,role,balance,created_at FROM users ORDER BY id DESC").all()));
app.get("/api/admin/orders",admin,(req,res)=>res.json(db.prepare(`SELECT o.*,u.email,s.name service_name FROM orders o JOIN users u ON u.id=o.user_id JOIN services s ON s.id=o.service_id ORDER BY o.id DESC`).all()));
app.patch("/api/admin/orders/:id",admin,(req,res)=>{
  const allowed=["Pending","Processing","Completed","Cancelled"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"Status tidak valid."});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
  res.json({ok:true});
});
app.post("/api/admin/topup",admin,(req,res)=>{
  const uid=Number(req.body.userId), amount=Number(req.body.amount);
  if(!Number.isInteger(uid)||!Number.isInteger(amount)||amount<=0) return res.status(400).json({error:"Top up tidak valid."});
  db.transaction(()=>{
    db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(amount,uid);
    db.prepare("INSERT INTO transactions(user_id,type,amount,note) VALUES(?,?,?,?)").run(uid,"credit",amount,"Admin top up");
  })();
  res.json({ok:true});
});
app.post("/api/admin/services",admin,(req,res)=>{
  const {name,platform,description,price}=req.body;
  if(!name||!platform||!Number(price)) return res.status(400).json({error:"Data layanan tidak lengkap."});
  db.prepare("INSERT INTO services(name,platform,description,price_per_1000) VALUES(?,?,?,?)").run(name,platform,description||"",Number(price));
  res.json({ok:true});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("Boostly running on http://localhost:"+(process.env.PORT||3000)));
